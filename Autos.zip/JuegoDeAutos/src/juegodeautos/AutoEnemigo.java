/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package juegodeautos;

/**
 *
 * @author alumnos.republica
 */
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.util.Random;
import javax.swing.ImageIcon;

public class AutoEnemigo {
    private int x, y;
    private int velocidad = 5;
    private Image imagen;
    private static final int ANCHO = 50, ALTO = 100;
    private Random rand = new Random();

public AutoEnemigo(int startX) {
    this.x = startX;
    this.y = -rand.nextInt(600);
    this.velocidad = 3 + rand.nextInt(5);
    this.imagen = new ImageIcon(getClass().getResource("/imgs/ft.png")).getImage();
}


    public void mover() {
        y += velocidad;
        if (y > 600) {
            reset();
        }
    }

    public void reset() {
    y = -ALTO;
    x = rand.nextInt(700);
    velocidad = 3 + rand.nextInt(5);
}


    public void dibujar(Graphics g) {
        g.drawImage(imagen, x, y, ANCHO, ALTO, null);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, ANCHO, ALTO);
    }
}
