/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package juegodeautos;

/**
 *
 * @author alumnos.republica
 */
import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class Explosion {
    private int x, y;
    private int radio;
    private int maxRadio;
    private boolean terminada = false;
    private Random rand;

    public Explosion(int x, int y) {
        this.x = x;
        this.y = y;
        this.radio = 10;
        this.maxRadio = 100;
        this.rand = new Random();
    }

    public void dibujar(Graphics g) {
        if (radio >= maxRadio) {
            terminada = true;
            return;
        }

        for (int i = 0; i < 20; i++) {
            int offsetX = rand.nextInt(radio) - radio / 2;
            int offsetY = rand.nextInt(radio) - radio / 2;
            int size = rand.nextInt(20) + 10;
            g.setColor(rand.nextBoolean() ? Color.RED : Color.ORANGE);
            g.fillOval(x + offsetX, y + offsetY, size, size);
        }

        radio += 10; // La explosión se agranda con el tiempo
    }

    public boolean estaTerminada() {
        return terminada;
    }
}
