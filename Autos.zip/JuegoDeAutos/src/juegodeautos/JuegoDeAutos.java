/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package juegodeautos;

/**
 *
 * @author alumnos.republica
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class JuegoDeAutos extends JPanel {
    private Auto auto;
    private ArrayList<Obstaculo> obstaculos;
    private boolean explotado = false;
    private Explosion explosion;
    private Timer timer;
    private JButton btnReiniciar;
    private int[] lineasY;
    private final int SEPARACION_LINEAS = 80;
    private ArrayList<AutoEnemigo> enemigos;
    private final int ANCHO = 800, ALTO = 600;

    public JuegoDeAutos() {
        auto = new Auto(375, 500);
        
        
        lineasY = new int[10]; //

        for (int i = 0; i < lineasY.length; i++) {
        lineasY[i] = i * SEPARACION_LINEAS;
}


        // Crear obstáculos
        obstaculos = new ArrayList<>();
        obstaculos.add(new Obstaculo(200, 300, 60, 60));
        obstaculos.add(new Obstaculo(500, 150, 80, 50));
        enemigos = new ArrayList<>();
        enemigos.add(new AutoEnemigo(200));
        enemigos.add(new AutoEnemigo(400));
        enemigos.add(new AutoEnemigo(600));


        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (explotado) return;

                int key = e.getKeyCode();

                switch (key) {
                    case KeyEvent.VK_LEFT -> auto.moverIzquierda();
                    case KeyEvent.VK_RIGHT -> auto.moverDerecha();
                    case KeyEvent.VK_UP -> auto.moverArriba();
                    case KeyEvent.VK_DOWN -> auto.moverAbajo();
                }

                verificarColisiones();
                repaint();

            }
            
            
        });
    }
    
    public void setReiniciarButton(JButton btn) {
    this.btnReiniciar = btn;
}


    private void verificarColisiones() {
    Rectangle autoBounds = auto.getBounds();

    if (auto.getX() < 0 || auto.getX() + 50 > ANCHO ||
        auto.getY() < 0 || auto.getY() + 100 > ALTO) {
        iniciarExplosion(auto.getX(), auto.getY());
        return;
    }

    for (Obstaculo obs : obstaculos) {
        if (autoBounds.intersects(obs.getBounds())) {
            iniciarExplosion(auto.getX(), auto.getY());
            return;
        }
    }
}


@Override
public void paintComponent(Graphics g) {
    super.paintComponent(g);
    g.setColor(Color.GRAY);
    g.fillRect(0, 0, ANCHO, ALTO);
    

    g.setColor(Color.WHITE);
    for (int i = 0; i < lineasY.length; i++) {
    g.fillRect(395, lineasY[i], 10, 40);
    lineasY[i] += 10;

    if (lineasY[i] > ALTO) {
        lineasY[i] = 0;
    }
}

      for (AutoEnemigo enemigo : enemigos) {
    enemigo.mover();
    enemigo.dibujar(g);

    if (!explotado && auto.getBounds().intersects(enemigo.getBounds())) {
        iniciarExplosion(auto.getX(), auto.getY());
    }
}

    if (explotado && explosion != null) {
        explosion.dibujar(g);
    } else {
        auto.dibujar(g);
    }
}



    public static void main(String[] args) {
    JFrame frame = new JFrame("Juego de Autos 2D");
    JuegoDeAutos juego = new JuegoDeAutos();

    JButton btnReiniciar = new JButton("Reiniciar");
    btnReiniciar.setBounds(325, 330, 150, 40);
    btnReiniciar.setVisible(false);

    btnReiniciar.addActionListener(e -> {
        juego.reiniciarJuego();
        btnReiniciar.setVisible(false);
    });

    frame.setLayout(null);
    juego.setBounds(0, 0, 800, 600);
    frame.add(juego);
    frame.add(btnReiniciar);

    juego.setReiniciarButton(btnReiniciar); // Pasamos la referencia del botón al panel

    frame.setSize(800, 600);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setResizable(false);
    frame.setVisible(true);
}
    
    
   private void iniciarExplosion(int x, int y) {
    explotado = true;
    explosion = new Explosion(x, y);

    timer = new Timer(100, e -> {
        if (explosion.estaTerminada()) {
            timer.stop();
            if (btnReiniciar != null) {
                btnReiniciar.setVisible(true);
            }
        }
        repaint();
    });
    timer.start();
}


  public void reiniciarJuego() {
    auto = new Auto(375, 500);
    explotado = false;
    explosion = null;
    repaint();
}


}




