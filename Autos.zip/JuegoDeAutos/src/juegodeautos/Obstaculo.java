/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package juegodeautos;

/**
 *
 * @author alumnos.republica
 */
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Obstaculo {
    private int x, y, ancho, alto;

    public Obstaculo(int x, int y, int ancho, int alto) {
        this.x = x;
        this.y = y;
        this.ancho = ancho;
        this.alto = alto;
    }

    public void dibujar(Graphics g) {
        g.setColor(Color.BLACK);
        g.fillRect(x, y, ancho, alto);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, ancho, alto);
    }
}
