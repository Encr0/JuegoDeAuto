/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package juegodeautos;

/**
 *
 * @author alumnos.republica
 */

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Auto {
    private int x, y;
    private int velocidad;
    
    public Auto(int x, int y) {
        this.x = x;
        this.y = y;
        this.velocidad = 5; // Velocidad básica
        
        
    }

    // Métodos para mover el auto
    public void moverIzquierda() {
        x -= velocidad;
    }

    public void moverDerecha() {
        x += velocidad;
    }

    public void moverArriba() {
        y -= velocidad;
    }

    public void moverAbajo() {
        y += velocidad;
    }

    // Método para dibujar el auto
    public void dibujar(Graphics g) {
        g.setColor(Color.RED); // Color del auto
        g.fillRect(x, y, 50, 100); // Dibuja un rectángulo que representa el auto
    }

    // Getters y Setters
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
    
    public Rectangle getBounds() {
    return new Rectangle(x, y, 50, 100);
}

}

